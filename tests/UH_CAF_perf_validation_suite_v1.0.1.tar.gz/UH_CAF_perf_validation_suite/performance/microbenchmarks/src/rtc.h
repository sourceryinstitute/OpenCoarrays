#ifndef RTC_H
#define RTC_H
void get_rtc_(unsigned long long *rtc);
void get_rtc_res_(unsigned long long *res);
void get_rtc_perturb_(unsigned long long *perturb);
#endif
